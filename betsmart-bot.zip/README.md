# BETSMART Gamers Telegram Bot 🎰

Your automated casino tips bot that sends daily plays with your Gemini Casino affiliate link.

## What This Bot Does

✅ Welcomes new users automatically  
✅ Sends daily casino tips at 9 AM CST  
✅ Users can request instant tips with `/tip`  
✅ Tracks subscribers automatically  
✅ Always includes: https://geminicasino.com/?registration=true&promo=FB888  
✅ Runs 24/7 with zero maintenance

## 🚀 SIMPLE SETUP (3 Steps)

### Step 1: Get Your Bot Token

1. Open Telegram
2. Search for `@BotFather`
3. Send `/newbot`
4. Follow prompts - name it whatever you want
5. Copy the token (looks like: `1234567890:ABCdefGHI...`)

### Step 2: Deploy to Railway (FREE)

1. Go to https://railway.app
2. Click "Start a New Project"
3. Choose "Deploy from GitHub repo"
4. Connect this code (or click "Empty Project" and upload files)
5. In Railway, click "Variables" tab
6. Add: `TELEGRAM_BOT_TOKEN` = your token from Step 1
7. (Optional) Add: `ADMIN_TELEGRAM_ID` = your Telegram user ID for admin commands

### Step 3: Done!

Your bot is now running 24/7 automatically.

## 📱 Bot Commands

**For Users:**
- `/start` - Subscribe to daily tips
- `/tip` - Get instant casino play recommendation
- `/stop` - Unsubscribe
- `/help` - Show all commands
- `/stats` - See subscription status

**For You (Admin):**
- `/admin` - Show admin panel
- `/sendnow` - Send daily tip immediately
- `/userstats` - See detailed stats

## ⏰ Automated Daily Tips

Tips are sent automatically every day at **9 AM CST (3 PM UTC)**

Want to change the time? Edit line 112 in `index.js`:
```javascript
// Current: 9 AM CST (3 PM UTC)
cron.schedule('0 15 * * *', () => {
    sendDailyTip();
});

// Examples:
// 8 AM CST = '0 14 * * *'
// 12 PM CST = '0 18 * * *'  
// 6 PM CST = '0 0 * * *'
```

## 🎮 How It Works

1. User sends `/start` to your bot
2. They get subscribed automatically
3. Every day at 9 AM CST, all subscribers get a casino tip
4. Each tip includes your affiliate link
5. Users can request more tips anytime with `/tip`

## 📊 What Gets Tracked

- All subscriber user IDs (stored in `data/users.json`)
- Casino tips library (stored in `data/tips.json`)
- Automatically removes users who block the bot

## 🎯 Adding New Casino Tips

Edit the tips in `index.js` starting at line 66, or:

1. Stop the bot in Railway
2. Edit `data/tips.json` directly in Railway file browser
3. Restart the bot

Tip format:
```json
{
    "game": "🎰 Game Name",
    "tip": "Why this game is good...",
    "strategy": "How to play it..."
}
```

## 🔧 Troubleshooting

**Bot not responding?**
- Check Railway logs for errors
- Verify TELEGRAM_BOT_TOKEN is set correctly
- Make sure bot is started (Railway should auto-start)

**Daily tips not sending?**
- Check Railway logs at scheduled time
- Verify bot is running 24/7 (not sleeping)
- Railway free tier keeps bots running automatically

**Want to test daily tips?**
- Message your bot: `/admin`
- Then send: `/sendnow`
- It will immediately send tips to all users

## 💰 Your Affiliate Link

**ALWAYS USES:** https://geminicasino.com/?registration=true&promo=FB888

Every tip, every welcome message, every command response includes this link.

## 📈 Growth Strategy

1. Share your bot link: `t.me/YourBotUsername`
2. Post in crypto/gambling Telegram groups
3. Add to your social bios
4. Users can forward tips to friends
5. Bot automatically handles all new subscribers

## ⚙️ Files Explained

- `index.js` - Main bot code (all logic)
- `package.json` - Dependencies list
- `.env.example` - Config template
- `railway.json` - Railway deployment settings
- `data/users.json` - Subscriber list (auto-created)
- `data/tips.json` - Tips library (auto-created)

## 🎓 No Coding Required

This bot runs completely automatically once deployed. You don't need to touch the code again unless you want to:
- Change the daily tip time
- Add new casino games to the tips
- Customize the messages

## 📞 Need Help?

If something breaks:
1. Check Railway logs (click your project → "Logs" tab)
2. Copy any error messages
3. The error will tell you exactly what's wrong

---

Built for hands-off affiliate marketing. Set it and forget it. 🚀
