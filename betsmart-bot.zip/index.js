require('dotenv').config();
const TelegramBot = require('node-telegram-bot-api');
const cron = require('node-cron');
const fs = require('fs').promises;
const path = require('path');

// Bot configuration
const token = process.env.TELEGRAM_BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });

// Casino link - ALWAYS use this full URL
const CASINO_LINK = 'https://geminicasino.com/?registration=true&promo=FB888';

// File paths for data storage
const USERS_FILE = path.join(__dirname, 'data', 'users.json');
const TIPS_FILE = path.join(__dirname, 'data', 'tips.json');

// In-memory storage (backed by files)
let users = new Set();
let dailyTips = [];

// Initialize data directory and files
async function initializeData() {
    try {
        await fs.mkdir(path.join(__dirname, 'data'), { recursive: true });
        
        // Load users
        try {
            const usersData = await fs.readFile(USERS_FILE, 'utf8');
            users = new Set(JSON.parse(usersData));
            console.log(`Loaded ${users.size} users`);
        } catch (err) {
            console.log('No existing users file, starting fresh');
            await saveUsers();
        }
        
        // Load tips
        try {
            const tipsData = await fs.readFile(TIPS_FILE, 'utf8');
            dailyTips = JSON.parse(tipsData);
            console.log(`Loaded ${dailyTips.length} tips`);
        } catch (err) {
            console.log('No existing tips file, using defaults');
            dailyTips = getDefaultTips();
            await saveTips();
        }
    } catch (err) {
        console.error('Error initializing data:', err);
    }
}

// Save users to file
async function saveUsers() {
    try {
        await fs.writeFile(USERS_FILE, JSON.stringify([...users], null, 2));
    } catch (err) {
        console.error('Error saving users:', err);
    }
}

// Save tips to file
async function saveTips() {
    try {
        await fs.writeFile(TIPS_FILE, JSON.stringify(dailyTips, null, 2));
    } catch (err) {
        console.error('Error saving tips:', err);
    }
}

// Default casino tips
function getDefaultTips() {
    return [
        {
            game: "🎰 Sweet Bonanza",
            tip: "High volatility slot with massive multipliers! Best played with medium bets for extended sessions. Max win potential: 21,000x!",
            strategy: "Wait for 4+ scatters to trigger free spins, that's where the real money is."
        },
        {
            game: "🃏 Blackjack Classic",
            tip: "House edge as low as 0.5% with perfect basic strategy. One of the best odds in any casino!",
            strategy: "Always split Aces and 8s. Never split 10s. Double down on 11 against dealer 2-10."
        },
        {
            game: "🎲 Crash",
            tip: "Fast-paced multiplier game - cash out before it crashes! Popular with crypto players.",
            strategy: "Set auto-cashout at 2x for consistent small wins, or risk it for 10x+ moon shots."
        },
        {
            game: "🎯 Plinko",
            tip: "Pure RNG fun - drop the ball and watch it bounce to your prize. Low risk, steady entertainment.",
            strategy: "Medium risk setting offers best balance of win frequency and payout size."
        },
        {
            game: "🎰 Gates of Olympus",
            tip: "Zeus-themed slot from Pragmatic Play. Tumbling reels with multipliers up to 500x per spin!",
            strategy: "Buy bonus feature at 100x bet during peak hours for better RTP (rumored)."
        },
        {
            game: "🌟 Mines",
            tip: "Click tiles to avoid mines - the more you survive, the higher your multiplier. Pure skill and nerves!",
            strategy: "Start with 3 mines for practice. Move to 5 mines once comfortable for better payouts."
        },
        {
            game: "🎰 Sugar Rush",
            tip: "Candy-themed high volatility slot with cluster pays. Can explode with massive multiplier chains!",
            strategy: "Base game can be brutal - save balance for bonus buys if you're feeling lucky."
        },
        {
            game: "🎲 Dice",
            tip: "Classic provably fair dice - roll over or under your target number. You control the odds!",
            strategy: "Rolling over 50.50 gives you 49.5% win chance at 2x payout - house edge just 1%."
        },
        {
            game: "🎰 Book of Dead",
            tip: "Egyptian adventure slot - the OG high volatility classic. Max win: 5,000x your bet.",
            strategy: "The explorer symbol is your golden ticket. 3+ books trigger free spins with expanding symbols."
        },
        {
            game: "💎 Stake Originals",
            tip: "Provably fair in-house games with some of the best RTP in crypto gambling (98-99%).",
            strategy: "Try Limbo or Hilo for transparent, fair odds you can verify on blockchain."
        }
    ];
}

// Get random tip
function getRandomTip() {
    return dailyTips[Math.floor(Math.random() * dailyTips.length)];
}

// Format tip message
function formatTipMessage(tip) {
    return `🎮 *TODAY'S CASINO PLAY* 🎮

${tip.game}

💡 *The Play:*
${tip.tip}

🎯 *Strategy:*
${tip.strategy}

🚀 *Ready to try it?*
Get your NEW PLAYER BONUS here:
${CASINO_LINK}

💰 Plus get 40% rakeback on all your plays!

_Good luck and play responsibly!_ 🍀`;
}

// Send daily tip to all users
async function sendDailyTip() {
    const tip = getRandomTip();
    const message = formatTipMessage(tip);
    
    console.log(`Sending daily tip to ${users.size} users...`);
    let successCount = 0;
    let failCount = 0;
    
    for (const userId of users) {
        try {
            await bot.sendMessage(userId, message, { parse_mode: 'Markdown' });
            successCount++;
            // Small delay to avoid rate limits
            await new Promise(resolve => setTimeout(resolve, 50));
        } catch (err) {
            console.error(`Failed to send to user ${userId}:`, err.message);
            // If user blocked bot, remove them
            if (err.response && err.response.statusCode === 403) {
                users.delete(userId);
                failCount++;
            }
        }
    }
    
    await saveUsers();
    console.log(`Daily tip sent! Success: ${successCount}, Failed/Removed: ${failCount}`);
}

// Schedule daily tips (9 AM CST = 3 PM UTC)
// You can change this time - format is: minute hour day month weekday
cron.schedule('0 15 * * *', () => {
    console.log('Running scheduled daily tip...');
    sendDailyTip();
});

// Bot commands

// /start command
bot.onText(/\/start/, async (msg) => {
    const chatId = msg.chat.id;
    const firstName = msg.from.first_name || 'Player';
    
    users.add(chatId);
    await saveUsers();
    
    const welcomeMessage = `🎰 *Welcome to BETSMART GAMERS, ${firstName}!* 🎰

You're now subscribed to daily casino plays and strategies!

📱 *What I'll send you:*
• Daily game recommendations
• Winning strategies
• Hot tips from experienced players
• Exclusive bonuses

🎮 *Commands:*
/tip - Get instant play recommendation
/stop - Unsubscribe from daily tips
/help - Show all commands

🚀 *Get Started Now:*
New player? Get your welcome bonus:
${CASINO_LINK}

💰 *Why this link?*
• Exclusive new player bonuses
• 40% rakeback on ALL bets
• Trusted crypto casino

Let's win together! 🍀`;

    bot.sendMessage(chatId, welcomeMessage, { parse_mode: 'Markdown' });
});

// /tip command
bot.onText(/\/tip/, async (msg) => {
    const chatId = msg.chat.id;
    const tip = getRandomTip();
    const message = formatTipMessage(tip);
    
    bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
});

// /stop command
bot.onText(/\/stop/, async (msg) => {
    const chatId = msg.chat.id;
    
    if (users.has(chatId)) {
        users.delete(chatId);
        await saveUsers();
        bot.sendMessage(chatId, "😢 You've been unsubscribed from daily tips.\n\nYou can always /start again to rejoin!");
    } else {
        bot.sendMessage(chatId, "You're not currently subscribed. Use /start to subscribe!");
    }
});

// /help command
bot.onText(/\/help/, (msg) => {
    const chatId = msg.chat.id;
    
    const helpMessage = `🎮 *BETSMART GAMERS BOT* 🎮

*Available Commands:*

/start - Subscribe to daily casino tips
/tip - Get instant play recommendation  
/stop - Unsubscribe from daily tips
/stats - See your subscription status
/help - Show this help message

🔗 *Casino Link:*
${CASINO_LINK}

💡 *About Daily Tips:*
Every day at 9 AM CST, you'll get:
• A featured casino game
• Winning strategies
• Pro tips from experienced players

Play smart, play responsibly! 🍀`;

    bot.sendMessage(chatId, helpMessage, { parse_mode: 'Markdown' });
});

// /stats command
bot.onText(/\/stats/, (msg) => {
    const chatId = msg.chat.id;
    const isSubscribed = users.has(chatId);
    
    const statsMessage = `📊 *Your Stats*

Status: ${isSubscribed ? '✅ Subscribed' : '❌ Not Subscribed'}
Total Subscribers: ${users.size}

${!isSubscribed ? '\nUse /start to subscribe to daily tips!' : ''}`;

    bot.sendMessage(chatId, statsMessage, { parse_mode: 'Markdown' });
});

// Admin commands (only work for you - add your Telegram user ID)
const ADMIN_ID = process.env.ADMIN_TELEGRAM_ID; // You'll set this

bot.onText(/\/admin/, async (msg) => {
    const chatId = msg.chat.id;
    
    if (ADMIN_ID && chatId.toString() === ADMIN_ID) {
        const adminMessage = `👑 *ADMIN PANEL*

*Commands:*
/broadcast [message] - Send to all users
/sendnow - Send daily tip immediately
/userstats - Detailed user statistics

*Current Status:*
Total Users: ${users.size}
Total Tips: ${dailyTips.length}`;

        bot.sendMessage(chatId, adminMessage, { parse_mode: 'Markdown' });
    }
});

bot.onText(/\/sendnow/, async (msg) => {
    const chatId = msg.chat.id;
    
    if (ADMIN_ID && chatId.toString() === ADMIN_ID) {
        bot.sendMessage(chatId, 'Sending daily tip to all users...');
        await sendDailyTip();
        bot.sendMessage(chatId, '✅ Daily tip sent!');
    }
});

bot.onText(/\/userstats/, (msg) => {
    const chatId = msg.chat.id;
    
    if (ADMIN_ID && chatId.toString() === ADMIN_ID) {
        const stats = `📊 *DETAILED STATS*

Total Subscribers: ${users.size}
Active Tips: ${dailyTips.length}
Bot Uptime: Online ✅

Next scheduled tip: Daily at 9 AM CST`;

        bot.sendMessage(chatId, stats, { parse_mode: 'Markdown' });
    }
});

// Handle any text message (engagement)
bot.on('message', (msg) => {
    // Just log for now - you can add more interactive features later
    if (!msg.text?.startsWith('/')) {
        console.log(`Message from ${msg.chat.id}: ${msg.text}`);
    }
});

// Error handling
bot.on('polling_error', (error) => {
    console.error('Polling error:', error);
});

// Initialize and start
console.log('🤖 BETSMART Gamers Bot starting...');
initializeData().then(() => {
    console.log('✅ Bot is running!');
    console.log(`📊 Active users: ${users.size}`);
    console.log('⏰ Daily tips scheduled for 9 AM CST (3 PM UTC)');
});
